#!/bin/bash
# ------------------------------------------------------------------
# dsh-launcher — macOS 桌面启动器：双击即起 DSH Web GUI
#
# 为什么需要它：`dsh web` 启动时会打印一条带进程 token 的 URL，
# 浏览器靠它换取签名 cookie；没有 token 直接访问 3080 只会得到
# 401 "dsh web authentication required"。Finder 双击不会给你这个 URL，
# 所以由本脚本负责启动、从启动输出里抓 URL、并打开它。
#
# 行为：
#   • 已在运行（且缓存 URL 仍有效）→ 直接打开缓存的 URL，不重启
#   • 未运行 / 缓存失效 → 重启 DSH，抓新 URL 并打开
#   • DSH 自身会打开浏览器；失败时本脚本再补一次 open
#   • 关闭本窗口不影响 DSH（nohup 脱离）；停止用双击桌面的「停止 DSH.command」
#
# 环境变量（一般不用改，测试时才用）：
#   DSH_LAUNCHER_BIN   dsh 可执行文件路径（默认 ~/.npm-global/bin/dsh）
#   DSH_LAUNCHER_LOG   DSH 输出日志（默认 ~/.dsh/web.log）
#   DSH_LAUNCHER_CACHE 已认证 URL 缓存（默认 ~/.dsh/web.url，格式：URL + PID 两行）
#   DSH_LAUNCHER_PORT  端口（默认 3080）
# ------------------------------------------------------------------
set -u

PORT="${DSH_LAUNCHER_PORT:-3080}"
URL_CACHE="${DSH_LAUNCHER_CACHE:-$HOME/.dsh/web.url}"
LOG="${DSH_LAUNCHER_LOG:-$HOME/.dsh/web.log}"

# Finder 双击是非登录 shell，PATH 里没有 /usr/local/bin 与 ~/.npm-global/bin。
# 只【追加】标准目录到 PATH 末尾：Finder 场景下它们本来就不在，补上即可；
# 而测试注入的 PATH 前缀（mock lsof/dsh）不会被标准目录遮住。
# ~/homebrew/bin 也必须在列：本机 brew 装在那里（不是 /opt/homebrew），
# uv / pyw / 其它 python 入口都从这里进 PATH。2026-10-28 加。
export PATH="$PATH:/usr/local/bin:/opt/homebrew/bin:$HOME/homebrew/bin:$HOME/.npm-global/bin:/usr/sbin:/sbin"

say() { printf '%s\n' "$*"; }
pause_exit() {
  say ""
  say "按回车键关闭…"
  read -r _ 2>/dev/null || true
  exit "${1:-0}"
}

# ---- 定位 dsh ----------------------------------------------------------
DSH_BIN="${DSH_LAUNCHER_BIN:-}"
if [ -z "$DSH_BIN" ]; then
  DSH_BIN="$(command -v dsh 2>/dev/null || true)"
fi
if [ -z "$DSH_BIN" ] || [ ! -x "$DSH_BIN" ]; then
  say "✗ 找不到 dsh。找过：\${DSH_LAUNCHER_BIN}、PATH（含 ~/.npm-global/bin）"
  say "  安装：npm i -g @deepseek-ai/dsh"
  pause_exit 1
fi

# ---- 系统提示词中文化补丁（幂等；失败不影响启动）------------------------
# DSH 升级会覆盖 node_modules 里被改过的提示词，这里每次启动顺带补回中文。
# 脚本自带备份与 node --check 校验；已中文化时零改动、静默跳过，实测约 0.05s。
PATCH_PY="$(cd "$(dirname "$0")" && pwd)/dsh-prompts-zh.py"
if [ -f "$PATCH_PY" ] && command -v python3 >/dev/null 2>&1; then
  PATCH_SUM="$(python3 "$PATCH_PY" 2>&1 | grep -E '合计' | tail -1)"
  case "$PATCH_SUM" in
    *"0 个文件、0 处"*) : ;;
    *"合计"*) [ -n "$PATCH_SUM" ] && say "▸ 提示词中文化：${PATCH_SUM}" ;;
  esac
fi

# ---- 端口占用检查 ------------------------------------------------------
port_pid() { lsof -nP -iTCP:"$PORT" -sTCP:LISTEN -t 2>/dev/null | head -1; }

# ---- 缓存 URL 是否属于「端口上这个进程」-------------------------------
# token 是每个进程新生成的，进程换了 token 就作废；且它只在启动输出里出现一次，
# 事后无法再取回。所以缓存里同时记 PID：PID 相同 ⇒ 同一进程 ⇒ URL 仍有效。
# 缓存格式：第 1 行 URL，第 2 行 PID。
cached_url_for_pid() {   # $1 = 当前监听 PID
  [ -s "$URL_CACHE" ] || return 1
  local u p
  u="$(head -1 "$URL_CACHE")"
  p="$(sed -n '2p' "$URL_CACHE")"
  [ -n "$u" ] && [ -n "$p" ] && [ "$p" = "$1" ]
}

open_url() {
  if [ -n "${DSH_LAUNCHER_NO_OPEN:-}" ]; then
    say "▸ （测试模式，不打开浏览器）URL: $1"
    return 0
  fi
  open "$1" >/dev/null 2>&1 || say "⚠ 无法自动打开浏览器，请手动访问：$1"
}

say "▸ DSH Web 启动器（端口 ${PORT}）"

# ---- 情形 1：已在运行，且缓存的 URL 就是它给的 → 直接开，不重启 --------
LIVE_PID="$(port_pid)"
if [ -n "$LIVE_PID" ] && cached_url_for_pid "$LIVE_PID"; then
  say "✓ DSH 已在运行（PID ${LIVE_PID}），复用它的认证 URL"
  open_url "$(head -1 "$URL_CACHE")"
  pause_exit 0
fi

# ---- 情形 2：端口被非 DSH 进程占用 → 不动它 ---------------------------
# 注意：macOS 上 DSH 的可执行文件是 node（命令行形如
# `node /Users/…/.npm-global/bin/dsh --profile web`），所以必须看完整命令行，
# 只看 lsof 的 txt（可执行文件）会把自家实例误判成外来进程。
PID="$LIVE_PID"
if [ -n "$PID" ]; then
  CMDLINE="$(ps -p "$PID" -o command= 2>/dev/null || true)"
  DESC="$CMDLINE"
  [ -n "$DESC" ] || DESC="$(lsof -p "$PID" 2>/dev/null | awk '$4=="txt"{print $NF}' | head -1)"
  case "$DESC" in
    *dsh*|*deepseek*) : ;;   # 是 DSH 的旧实例 → 可以重启
    *)
      say "✗ 端口 $PORT 被别的进程占用（PID ${PID}），我不会动它："
      say "    ${DESC:-（读不到命令行）}"
      say "  要么关掉它，要么设 DSH_LAUNCHER_PORT 换端口。"
      pause_exit 1
      ;;
  esac
fi

# ---- 重启：旧实例（若有）杀掉 → 起新实例 ------------------------------
if [ -n "$PID" ]; then
  say "▸ 清理旧实例（PID ${PID}）…"
  pkill -f "bin/dsh --profile web" 2>/dev/null || kill "$PID" 2>/dev/null || true
  n=0
  while [ -n "$(port_pid)" ] && [ "$n" -lt 20 ]; do sleep 0.3; n=$((n + 1)); done
  if [ -n "$(port_pid)" ]; then
    say "✗ 端口 $PORT 仍未释放，请手动处理：kill $(port_pid)"
    pause_exit 1
  fi
fi

mkdir -p "$(dirname "$LOG")" 2>/dev/null || true
if ! : >>"$LOG" 2>/dev/null; then
  say "✗ 日志不可写：$LOG"
  pause_exit 1
fi

# 记录本行前的日志长度：URL 只可能出现在其后，避免抓到上一次运行的旧 URL
BEFORE=$(wc -l <"$LOG" | tr -d ' ')

say "▸ 正在启动 dsh web …（日志：${LOG}）"
# 用 nohup 脱离本终端：关掉这个窗口 DSH 不会被带走。
# --no-open：由本脚本统一开浏览器，避免 DSH 与本脚本各开一次。
nohup "$DSH_BIN" web --port "$PORT" --no-open >>"$LOG" 2>&1 &
DSH_PID=$!
say "  PID ${DSH_PID}（关闭本窗口不影响它）"

# ---- 等启动输出里的认证 URL ------------------------------------------
URL=""
i=0
while [ "$i" -lt 120 ]; do   # 最多约 30 秒
  URL="$(tail -n +"$((BEFORE + 1))" "$LOG" 2>/dev/null | sed -n 's/^dsh web: \(http[^ ]*\).*/\1/p' | tail -1)"
  [ -n "$URL" ] && break
  npid="$(port_pid)"
  if [ -z "$npid" ] && ! kill -0 "$DSH_PID" 2>/dev/null; then break; fi
  sleep 0.25
  i=$((i + 1))
done

if [ -z "$URL" ]; then
  say "✗ 启动失败或超时（30 秒内没等到认证 URL）。日志末尾："
  say "------------------------------------------------------------"
  tail -20 "$LOG" 2>/dev/null | sed 's/^/  /'
  say "------------------------------------------------------------"
  pause_exit 1
fi

printf '%s\n%s\n' "$URL" "$DSH_PID" >"$URL_CACHE"
chmod 600 "$URL_CACHE" 2>/dev/null || true
say "✓ 已就绪：$URL"

# DSH 已就绪，但浏览器交给我们开（--no-open），失败时给出可手点的 URL
sleep 1
open_url "$URL"
pause_exit 0
